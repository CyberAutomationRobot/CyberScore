#!/bin/bash
# Get the absolute directory path where this script is located
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
echo 'Launching application...'

# Detect the architecture
arch=$(uname -m)
if [ "$arch" = "x86_64" ]; then
    binary="$script_dir/CyberScoreMacOSIntel"
elif [ "$arch" = "arm64" ]; then
    binary="$script_dir/CyberScoreMacOSApple"
else
    echo "Unsupported architecture: $arch"
    exit 1
fi

# Output the path of the binary to run
echo "Executable path: $binary"

# Write the full path to a temporary file
echo "$binary" > /tmp/terraview_path.txt

# Use AppleScript to open a new Terminal window and run the binary from the path in the temp file
osascript <<EOF
tell application "Terminal"
    set scriptPath to (do shell script "cat /tmp/terraview_path.txt")
    do script "clear"
    delay 1  -- Waits for the clear command to execute
    do script "\"" & scriptPath & "\"" in front window
    activate
end tell
EOF
